I have built this gui app in VScode
Install VScode
Install python extension in VScode and create a new project 
Name your project as "name.py"
Paste the code and run it


*******************NOTE******************
there might be some currencies which will not work because the api i have used only
supports 160 currencies.